package com.sunnyfit.app

import android.os.Bundle
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Cream=Color(0xFFFFF8E9); private val Sky=Color(0xFF79C8F2); private val Ink=Color(0xFF243746)
data class City(val name:String,val country:String,val lat:Double,val lon:Double)
data class RowData(val label:String,val value:String)
class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  scheduleWeatherNotifications(this)
  if(Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED){
   requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 701)
  }
  setContent{SunnyFit()}
 }
}

@Composable fun SunnyFit(){
 var city by remember{mutableStateOf(City("Berlin","Germany",52.52,13.405))}
 var query by remember{mutableStateOf("Berlin")}
 var choices by remember{mutableStateOf(listOf<City>())}
 var lines by remember{mutableStateOf(listOf<RowData>())}
 var status by remember{mutableStateOf("در حال دریافت اطلاعات هواشناسی…")}
 var en by remember{mutableStateOf(false)}
 var busy by remember{mutableStateOf(false)}
 val context = LocalContext.current
 val scope= rememberCoroutineScope()
 fun load(c:City){scope.launch{busy=true;status=if(en)"Loading live weather…" else "در حال دریافت اطلاعات زنده…"
  try{lines=weather(c);city=c;saveCity(context,c);status=if(en)"Updated from Open-Meteo" else "به‌روزرسانی از سرویس Open-Meteo"}
  catch(e:Exception){status=e.message?: "خطا در دریافت اطلاعات"} finally{busy=false}}}
 LaunchedEffect(Unit){load(city)}
 MaterialTheme(colorScheme=lightColorScheme(primary=Sky,background=Cream,surface=Color.White)){
  Column(Modifier.fillMaxSize().background(Cream).padding(16.dp)){
   Row(verticalAlignment=Alignment.CenterVertically){Text("👕☀️",fontSize=27.sp);Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text("SunnyFit",fontSize=26.sp,fontWeight=FontWeight.Bold,color=Ink);Text(if(en)"Live weather & outfit guide" else "هواشناسی زنده و پیشنهاد لباس",color=Ink)};TextButton(onClick={en=!en}){Text(if(en)"فارسی" else "EN")}}
   Spacer(Modifier.height(14.dp))
   OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text(if(en)"Search a city worldwide" else "جست‌وجوی شهر در سراسر دنیا")},singleLine=true)
   Row {Button(onClick={scope.launch { busy=true;try{choices=searchCity(query);if(choices.isEmpty())status=if(en)"City not found" else "شهری پیدا نشد"}catch(e:Exception){status=e.message?: "خطا"}finally{busy=false}}}){Text(if(en)"Search" else "جست‌وجو")};Spacer(Modifier.width(8.dp));OutlinedButton(onClick={ load(city) }){Text(if(en)"Refresh" else "تازه‌سازی")}}
   choices.take(5).forEach{c->TextButton(onClick={choices= emptyList();query=c.name;load(c)}){Text("${c.name}, ${c.country}")}}
   Spacer(Modifier.height(8.dp));Text("${city.name}, ${city.country}",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
   if(busy)LinearProgressIndicator(Modifier.fillMaxWidth())
   Text(status,color=Ink,fontSize=12.sp)
   LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
    items(lines){r->Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(14.dp)){Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(r.label,color=Ink);Text(r.value,color=Ink,fontWeight=FontWeight.Bold)}}}
   }
   Text(if(en)"Data refreshes whenever you open, search or refresh the app. Internet required." else "با هر بار ورود، جست‌وجو یا تازه‌سازی، داده جدید دریافت می‌شود؛ اتصال اینترنت لازم است.",fontSize=11.sp,color=Ink)
  }
 }
}

suspend fun searchCity(q:String):List<City> = withContext(Dispatchers.IO){
 require(q.isNotBlank()){"نام شهر را وارد کن"}
 val encoded=URLEncoder.encode(q,"UTF-8")
 val j=get("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=6&language=en&format=json")
 val a=j.optJSONArray("results")?:return@withContext emptyList()
 (0 until a.length()).map{val o=a.getJSONObject(it);City(o.optString("name"),o.optString("country"),o.optDouble("latitude"),o.optDouble("longitude"))}
}
suspend fun weather(c:City):List<RowData> = withContext(Dispatchers.IO){
 val u="https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&hourly=temperature_2m,precipitation_probability&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&forecast_days=7&timezone=auto"
 val j=get(u);val cur=j.getJSONObject("current");val h=j.getJSONObject("hourly");val d=j.getJSONObject("daily")
 val out= mutableListOf<RowData>()
 val temp=cur.optDouble("temperature_2m");val code=cur.optInt("weather_code")
 out.add(RowData("دمای فعلی / Current", "${temp.toInt()}°C"))
 out.add(RowData("وضعیت / Condition",condition(code)))
 out.add(RowData("دمای حسی / Feels like","${cur.optDouble("apparent_temperature").toInt()}°C"))
 out.add(RowData("رطوبت / Humidity","${cur.optInt("relative_humidity_2m")}%"))
 out.add(RowData("سرعت باد / Wind","${cur.optDouble("wind_speed_10m").toInt()} km/h"))
 out.add(RowData("پیشنهاد لباس / Outfit",outfit(temp,code)))
 val ht=h.getJSONArray("time");val hv=h.getJSONArray("temperature_2m");val hp=h.getJSONArray("precipitation_probability")
 val now=cur.optString("time");var start=0
 for(i in 0 until ht.length()){if(ht.optString(i)>=now){start=i;break}}
 out.add(RowData("ــــ ۱۲ ساعت آینده / NEXT 12 HOURS ــــ",""))
 for(i in start until minOf(start+12,ht.length()))out.add(RowData(ht.optString(i).substringAfter("T"),"${hv.optDouble(i).toInt()}°C • بارش ${hp.optInt(i)}%"))
 val dt=d.getJSONArray("time");val mn=d.getJSONArray("temperature_2m_min");val mx=d.getJSONArray("temperature_2m_max");val pr=d.getJSONArray("precipitation_probability_max");val wc=d.getJSONArray("weather_code")
 out.add(RowData("ــــ پیش‌بینی ۷ روز / 7-DAY FORECAST ــــ",""))
 for(i in 0 until dt.length())out.add(RowData(dt.optString(i),"${mn.optDouble(i).toInt()}° / ${mx.optDouble(i).toInt()}° • بارش ${pr.optInt(i)}% • ${condition(wc.optInt(i))}"))
 out
}
fun get(url:String):JSONObject{val c=URL(url).openConnection() as HttpURLConnection;c.connectTimeout=15000;c.readTimeout=15000;try{val code=c.responseCode;val s=if(code in 200..299)c.inputStream else c.errorStream;val body=s.bufferedReader().use{it.readText()};if(code !in 200..299)error("خطای سرویس هواشناسی: $code");return JSONObject(body)}finally{c.disconnect()}}
fun condition(c:Int)=when(c){0->"آفتابی ☀️";1,2->"کمی ابری 🌤️";3->"ابری ☁️";45,48->"مه 🌫️";in 51..67->"بارانی 🌧️";in 71..77->"برفی ❄️";in 80..82->"رگبار 🌦️";in 95..99->"رعدوبرق ⛈️";else->"متغیر"}
fun outfit(t:Double,c:Int)=when{c in 51..99&&t<12->"کاپشن ضدآب و چتر";c in 51..99->"بارانی و چتر";t<5->"کاپشن ضخیم، شال و دستکش";t<13->"کاپشن یا سویشرت گرم";t<20->"ژاکت سبک";t<27->"لباس نخی راحت";else->"لباس خنک و رنگ روشن"}


private const val WEATHER_CHANNEL = "sunnyfit_weather"
private const val WEATHER_WORK_NAME = "sunnyfit_periodic_weather"

private fun saveCity(context: Context, city: City) {
    context.getSharedPreferences("sunnyfit", Context.MODE_PRIVATE).edit()
        .putString("city_name", city.name)
        .putString("country", city.country)
        .putFloat("lat", city.lat.toFloat())
        .putFloat("lon", city.lon.toFloat())
        .apply()
}

private fun scheduleWeatherNotifications(context: Context) {
    val request = PeriodicWorkRequestBuilder<SunnyFitWeatherWorker>(6, TimeUnit.HOURS)
        .build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        WEATHER_WORK_NAME,
        ExistingPeriodicWorkPolicy.UPDATE,
        request
    )
}

class SunnyFitWeatherWorker(context: Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            val prefs = applicationContext.getSharedPreferences("sunnyfit", Context.MODE_PRIVATE)
            val name = prefs.getString("city_name", "Berlin") ?: "Berlin"
            val country = prefs.getString("country", "Germany") ?: "Germany"
            val lat = prefs.getFloat("lat", 52.52f).toDouble()
            val lon = prefs.getFloat("lon", 13.405f).toDouble()
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code,apparent_temperature&timezone=auto"
            val data = withContext(Dispatchers.IO) { get(url) }
            val current = data.getJSONObject("current")
            val temp = current.optDouble("temperature_2m").toInt()
            val feels = current.optDouble("apparent_temperature").toInt()
            val condition = condition(current.optInt("weather_code"))
            val outfit = outfit(current.optDouble("temperature_2m"), current.optInt("weather_code"))
            showWeatherNotification(
                applicationContext,
                "SunnyFit • $name, $country",
                "$condition  $temp°C | دمای حسی $feels°C\nپیشنهاد لباس: $outfit"
            )
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

private fun showWeatherNotification(context: Context, title: String, message: String) {
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = android.app.NotificationChannel(
            WEATHER_CHANNEL, "SunnyFit Weather", android.app.NotificationManager.IMPORTANCE_DEFAULT
        )
        manager.createNotificationChannel(channel)
    }
    if (Build.VERSION.SDK_INT >= 33 &&
        ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    ) return

    val notification = NotificationCompat.Builder(context, WEATHER_CHANNEL)
        .setSmallIcon(android.R.drawable.ic_menu_compass)
        .setContentTitle(title)
        .setContentText(message.replace("\n", " • "))
        .setStyle(NotificationCompat.BigTextStyle().bigText(message))
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .setAutoCancel(true)
        .build()
    NotificationManagerCompat.from(context).notify(4201, notification)
}
